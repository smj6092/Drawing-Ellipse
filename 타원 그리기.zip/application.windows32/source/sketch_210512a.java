import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class sketch_210512a extends PApplet {

int X_MIN = 400;
int X_MAX = 1520;
int Y_MIN = 300;
int Y_MAX = 780;
int SCREEN_X = 1920;
int SCREEN_Y = 1080;
int WEIGHT = 5;

float a;
float b;
float XOffset;
float YOffset;
int mode;  // 0 = 기울기, 1 = 좌표
float m;
float xpos;
float ypos;

String config[];
String values[]; 

float scale;
int centerX;
int centerY;

public void setup() {
  config = loadStrings("config.tsv");  // 설정 값
  X_MIN = parseInt(config[1]);
  X_MAX = parseInt(config[4]);
  Y_MIN = parseInt(config[7]);
  Y_MAX = parseInt(config[10]);
  SCREEN_X = parseInt(config[13]);
  SCREEN_Y = parseInt(config[16]);
  WEIGHT = parseInt(config[19]);
  values = loadStrings("values.tsv");  // 타원 및 접선에 쓰일 값
  a = sqrt(parseFloat(values[1]));
  b = sqrt(parseFloat(values[4]));
  XOffset = parseFloat(values[7]);
  YOffset = parseFloat(values[10]);
  mode = parseInt(values[13]);
  m = parseFloat(values[16]);
  xpos = parseFloat(values[19]);
  ypos = parseFloat(values[22]);
  
  centerX = (X_MIN + X_MAX)/2;
  centerY = (Y_MIN + Y_MAX)/2;
  
  float XScale = 2*a/(X_MAX-X_MIN);
  float YScale = 2*b/(Y_MAX-Y_MIN);
  if(XScale > YScale) {
    scale = XScale;
  } else {
    scale = YScale;
  }
  drawBackground();
  drawEllipse();
  drawLine();
}

public void drawBackground() {  // 좌표계
  background(0);
  float unit = 1;
  while(unit < scale * 10)
  {
    unit *= 10;
  }
  stroke(128);
  textSize(WEIGHT*2);
  
  fill(255);
  textAlign(LEFT,CENTER);
  for(float i = (round(-YOffset/unit)-15)*unit; centerY+YOffset/scale+(i-unit)/scale < SCREEN_Y; i+= unit)
  {
    line(0, centerY+YOffset/scale+i/scale, SCREEN_X, centerY+YOffset/scale+i/scale);
    text(round(-i), 0, centerY+YOffset/scale+i/scale);
  }
  textAlign(CENTER);
  for(float i = (round(XOffset/unit)-25)*unit; centerX-XOffset/scale+(i-unit)/scale < SCREEN_X; i+= unit)
  {
    line(centerX-XOffset/scale+i/scale, 0, centerX-XOffset/scale+i/scale, SCREEN_Y);
    text(round(i), centerX-XOffset/scale+i/scale, WEIGHT+2);
  }
}

public void drawEllipse() {  // 타원
  float XWidth = a/scale*2;
  float YWidth = b/scale*2;
  String f = "";
  smooth();
  noFill();
  strokeWeight(WEIGHT);
  stroke(255,255,0);
  ellipse(centerX,centerY,XWidth,YWidth);
  noStroke();
  fill(255,0,0);
  textSize(WEIGHT*4);
  textAlign(CENTER);
  if(XWidth > YWidth) {
    circle(centerX+sqrt(a*a-b*b)/scale, centerY, WEIGHT*2);
    circle(centerX-sqrt(a*a-b*b)/scale, centerY, WEIGHT*2);
    text("("+(sqrt(a*a-b*b)+XOffset)+","+YOffset+")",centerX+sqrt(a*a-b*b)/scale, centerY-WEIGHT*2);
    text("("+(-sqrt(a*a-b*b)+XOffset)+","+YOffset+")",centerX-sqrt(a*a-b*b)/scale, centerY-WEIGHT*2);
  } else {
    circle(centerX, centerY+sqrt(b*b-a*a)/scale, WEIGHT*2);
    circle(centerX, centerY-sqrt(b*b-a*a)/scale, WEIGHT*2);
    text("("+XOffset+","+(-sqrt(b*b-a*a)+YOffset)+")",centerX, centerY+sqrt(b*b-a*a)/scale-WEIGHT*2);
    text("("+XOffset+","+(sqrt(b*b-a*a)+YOffset)+")",centerX, centerY-sqrt(b*b-a*a)/scale+WEIGHT*4);
  }
  if(XOffset == 0)
  {
    f += "x²";
  }  else  {
    f += "(x";
    if(XOffset<0) {
      f += "+";
    }
    f += (-XOffset)+ ")²/" + (a*a);
  }
  if(YOffset == 0)
  {
    f += "y²";
  }  else  {
    f += "(y";
    if(YOffset<0) {
      f += "+";
    }
    f += (-YOffset)+ ")²/" + (b*b) + "=1";
  }
  fill(255,255,0);
  textSize(WEIGHT*4);
  textAlign(RIGHT,BOTTOM);
  text(f,SCREEN_X-WEIGHT*4,SCREEN_Y-WEIGHT-80);
}

public void drawLine() {  // 접선
  float YInt;
  float x1;
  float y1;
  float x2;
  float y2;
  String f1 = "y=";
  String f2 = "y=";
  strokeWeight(WEIGHT);
  if(mode == 0) {  // 기울기로 그리기
    YInt = sqrt(a*a*m*m+b*b)/scale;
    stroke(255,0,255);
    line(0, centerY+YInt+centerX*m, SCREEN_X, centerY+YInt-(SCREEN_X-centerX)*m);
    stroke(0,255,255);
    line(0, centerY-YInt+centerX*m, SCREEN_X, centerY-YInt-(SCREEN_X-centerX)*m);
    noStroke();
    fill(0,255,0);
    x1 = a*a*m/sqrt(a*a*m*m+b*b);
    y1 = -b*b/sqrt(a*a*m*m+b*b);
    x2 = -a*a*m/sqrt(a*a*m*m+b*b);
    y2 = b*b/sqrt(a*a*m*m+b*b);
    circle(centerX+x1/scale,centerY-y1/scale,WEIGHT*2);
    circle(centerX+x2/scale,centerY-y2/scale,WEIGHT*2);
    textAlign(CENTER);
    textSize(WEIGHT*4);
    text("("+(x1+XOffset)+","+(y1+YOffset)+")",centerX+x1/scale,centerY-y1/scale-WEIGHT*2);
    text("("+(x2+XOffset)+","+(y2+YOffset)+")",centerX+x2/scale,centerY-y2/scale-WEIGHT*2);
    
    f1 += m + "x";
    f2 += m + "x";
    if(-sqrt(a*a*m*m+b*b) + YOffset - m * XOffset >= 0) {
      f1 += "+";
    }
    if(sqrt(a*a*m*m+b*b) + YOffset - m * XOffset >= 0) {
      f2 += "+";
    }
    f1 += (-sqrt(a*a*m*m+b*b) + YOffset - m * XOffset);
    f2 += (sqrt(a*a*m*m+b*b) + YOffset - m * XOffset);
    if(m == 0) {
      f1 = "y=" + (-sqrt(a*a*m*m+b*b) + YOffset - m * XOffset);
      f2 = "y=" + (sqrt(a*a*m*m+b*b) + YOffset - m * XOffset);
    }
  } else {  // 한 점으로부터 그리기
    xpos -= XOffset;
    ypos -= YOffset;
    x1 = (a*a*b*b*xpos+a*a*ypos*sqrt(a*a*ypos*ypos-a*a*b*b+b*b*xpos*xpos))/(a*a*ypos*ypos+b*b*xpos*xpos);
    y1 = (a*a*b*b*ypos-b*b*xpos*sqrt(a*a*ypos*ypos-a*a*b*b+b*b*xpos*xpos))/(a*a*ypos*ypos+b*b*xpos*xpos);
    x2 = (a*a*b*b*xpos-a*a*ypos*sqrt(a*a*ypos*ypos-a*a*b*b+b*b*xpos*xpos))/(a*a*ypos*ypos+b*b*xpos*xpos);
    y2 = (a*a*b*b*ypos+b*b*xpos*sqrt(a*a*ypos*ypos-a*a*b*b+b*b*xpos*xpos))/(a*a*ypos*ypos+b*b*xpos*xpos);
    stroke(255,0,255);
    if(x1 == a || x1 == -a) {
      line(centerX+x1/scale,0,centerX+x1/scale,SCREEN_Y);
    } else {
      line(0,centerY-y1/scale+(centerX+x1/scale)*(y1-ypos)/(x1-xpos), SCREEN_X, centerY-ypos/scale-(SCREEN_X-centerX-xpos/scale)*(y1-ypos)/(x1-xpos));
    }
    stroke(0,255,255);
    if(x2 == a || x2 == -a) {
      line(centerX+x2/scale,0,centerX+x2/scale,SCREEN_Y);
    } else {
      line(0,centerY-y2/scale+(centerX+x2/scale)*(y2-ypos)/(x2-xpos), SCREEN_X, centerY-ypos/scale-(SCREEN_X-centerX-xpos/scale)*(y2-ypos)/(x2-xpos));
    }
    noStroke();
    fill(0,255,0);
    circle(centerX+x1/scale,centerY-y1/scale,WEIGHT*2);
    circle(centerX+x2/scale,centerY-y2/scale,WEIGHT*2);
    textAlign(CENTER);
    textSize(WEIGHT*4);
    fill(0, 255, 0);
    text("("+(x1+XOffset)+","+(y1+YOffset)+")",centerX+x1/scale,centerY-y1/scale-WEIGHT*2);
    text("("+(x2+XOffset)+","+(y2+YOffset)+")",centerX+x2/scale,centerY-y2/scale-WEIGHT*2);
    f1 += (y1-ypos)/(x1-xpos) + "x";
    f2 += (y2-ypos)/(x2-xpos) + "x";
    if(y1+YOffset-(x1+XOffset)*(y1-ypos)/(x1-xpos) >= 0) {
      f1 += "+";
    }
    if(y2+YOffset-(x2+XOffset)*(y2-ypos)/(x2-xpos) >= 0) {
      f2 += "+";
    }
    f1 += (y1+YOffset-(x1+XOffset)*(y1-ypos)/(x1-xpos));
    f2 += (y2+YOffset-(x2+XOffset)*(y2-ypos)/(x2-xpos));
    if(x1 == xpos)
    {
      f1 = "x=" + (x1 + XOffset);
    }
    if(x2 == xpos)
    {
      f2 = "x=" + (x2 + XOffset);
    }
    if(y1 == ypos)
    {
      f1 = "y=" + (y1 + YOffset);
    }
    if(y2 == ypos)
    {
      f2 = "y=" + (y2 + YOffset);
    }
  }
  textAlign(RIGHT,BOTTOM);
  fill(255,0,255);
  text(f1,SCREEN_X-WEIGHT*4,SCREEN_Y-WEIGHT-80-WEIGHT*4);
  fill(0,255,255);
  text(f2,SCREEN_X-WEIGHT*4,SCREEN_Y-WEIGHT-80-WEIGHT*8);
}
  public void settings() {  size(1920,1080); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "sketch_210512a" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
